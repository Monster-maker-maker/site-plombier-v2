<?php include('header.php'); ?>
<main>
  <h1>Bienvenue chez votre plombier à Toulouse</h1>
  <p>Professionnel, rapide et disponible 7j/7.</p>
</main>
<?php include('footer.php'); ?>