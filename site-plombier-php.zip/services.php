<?php include('header.php'); ?>
<main>
  <h1>Mes Services</h1>
  <ul>
    <li>Réparation de fuites</li>
    <li>Installation de sanitaires</li>
    <li>Débouchage de canalisations</li>
  </ul>
</main>
<?php include('footer.php'); ?>