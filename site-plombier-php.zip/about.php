<?php include('header.php'); ?>
<main>
  <h1>À propos</h1>
  <p>Je suis plombier depuis 10 ans, basé à Toulouse.</p>
</main>
<?php include('footer.php'); ?>