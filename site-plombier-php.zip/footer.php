
<footer>
  <p>© 2025 Plombier Toulouse. Tous droits réservés.</p>
</footer>
</body>
</html>